CLUB AURA WEBSITE V2

This version uses the supplied Club Aura logo and the uploaded Club Aura photos.

IMPORTANT:
1. Open script.js and replace 919999999999 with the real Club Aura WhatsApp number.
2. Replace the Google Maps link in index.html with your exact Club Aura Maps link if desired.
3. The Instagram button was intentionally omitted until the exact Instagram URL is supplied.
4. Publish the folder with GitHub Pages for a free website.

Theme: black + antique gold + Greek-inspired luxury, matching the supplied logo.
